---
name: Feature request
about: Suggest/request a new bot feature
title: ''
labels: 'enhancement'
assignees: ''

---

**Explain your suggestion**
